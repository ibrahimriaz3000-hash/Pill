Dynamic Pill (LSPosed module)
1. Upload this project to a GitHub repo (keep .github/workflows/build.yml).
2. Actions tab -> Build APK -> download artifact DynamicPill-apk.
3. Install the APK, LSPosed -> Modules -> enable "Dynamic Pill" -> scope: System UI.
4. Reboot (or restart System UI). Open the app to adjust width/height/offset.
