package com.dynamicpill.module;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Settings screen for the module. Values are read live by System UI. */
public class MainActivity extends Activity {
    private SharedPreferences sp;

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_WORLD_READABLE);
        } catch (Throwable t) {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_PRIVATE);
            Toast.makeText(this, "Activate the module in LSPosed first", Toast.LENGTH_LONG).show();
        }

        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView info = new TextView(this);
        info.setText("1) LSPosed: enable this module for System UI\n"
                + "2) Reboot or restart System UI\n"
                + "3) Changes below apply live (within ~2 seconds)");
        root.addView(info);

        Switch enabled = new Switch(this);
        enabled.setText("Show pill");
        enabled.setChecked(sp.getBoolean(PillController.K_ENABLED, true));
        enabled.setOnCheckedChangeListener((CompoundButton v, boolean on) ->
                sp.edit().putBoolean(PillController.K_ENABLED, on).apply());
        root.addView(enabled);

        Switch lock = new Switch(this);
        lock.setText("Show on lock screen");
        lock.setChecked(sp.getBoolean(PillController.K_LOCK, true));
        lock.setOnCheckedChangeListener((CompoundButton v, boolean on) ->
                sp.edit().putBoolean(PillController.K_LOCK, on).apply());
        root.addView(lock);

        addSlider(root, "Width", PillController.K_WIDTH, PillController.D_WIDTH, 40, 300, 0);
        addSlider(root, "Height", PillController.K_HEIGHT, PillController.D_HEIGHT, 20, 120, 0);
        addSlider(root, "Vertical offset", PillController.K_YOFF, PillController.D_YOFF, 0, 200, -100);

        final TextView aLabel = new TextView(this);
        aLabel.setPadding(0, 40, 0, 0);
        aLabel.setText("Opacity: " + sp.getInt(PillController.K_ALPHA, 100) + " %");
        root.addView(aLabel);
        SeekBar aBar = new SeekBar(this);
        aBar.setMax(100);
        aBar.setProgress(sp.getInt(PillController.K_ALPHA, 100));
        aBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                aLabel.setText("Opacity: " + p + " %");
                if (user) sp.edit().putInt(PillController.K_ALPHA, p).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(aBar);

        TextView sbTitle = new TextView(this);
        sbTitle.setText("\nStatus bar padding");
        sbTitle.setTextSize(18);
        sbTitle.setPadding(0, 60, 0, 0);
        root.addView(sbTitle);
        addSlider(root, "Left padding", PillController.K_PAD_L, 0, 0, 200, 0);
        addSlider(root, "Right padding", PillController.K_PAD_R, 0, 0, 200, 0);
        addSlider(root, "Top padding", PillController.K_PAD_T, 0, 0, 200, 0);

        ScrollView sv = new ScrollView(this);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
    }

    /** value (in 0.1 mm) = progress + shift; progress runs from 0..(max-min). */
    private void addSlider(LinearLayout root, String name, String key, int def,
                           int min, int max, int shift) {
        final TextView label = new TextView(this);
        int cur = sp.getInt(key, def);
        label.setText(name + ": " + (cur / 10f) + " mm");
        label.setPadding(0, 40, 0, 0);
        root.addView(label);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(cur - shift - min);
        final int minF = min, shiftF = shift;
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                int v = p + minF + shiftF;
                label.setText(name + ": " + (v / 10f) + " mm");
                if (user) sp.edit().putInt(key, v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(bar);
    }
}
